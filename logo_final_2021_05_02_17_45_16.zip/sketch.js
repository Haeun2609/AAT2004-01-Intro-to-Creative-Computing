var font = [];
var logo = [];
var brandName = ' ';
var bgcolorPicker;
var addingChanged;
var tselected = false;
var fselected = false;
var nselected = true; 
var f;
var cnv;


function preload(){
  font[0] = loadFont('fonts/DejaVuSerif.ttf')
  font[1] = loadFont('fonts/UVF SouciSansNF.ttf');
  font[2] = loadFont('fonts/UVF SolPro-MediumItalic.ttf');
  font[3] = loadFont('fonts/UVF Funkydori.ttf');
  font[4] = loadFont('fonts/UVF Frosting-for-Breakfast_regular.otf')
  font[5] = loadFont('fonts/UVF BrandPro.otf');
  font[6] = loadFont('fonts/HLT bauserif.ttf');
  font[7] = loadFont('fonts/HLT FoglihtenNo04.ttf');
}
function setup() {
  cnv = createCanvas(400, 400);
  textAlign(CENTER,CENTER);
  textFont(font[floor(random(0,7))])
  
  //First-sight display
  greet = createSpan("What's your brand name?");
  greet.style('font-size','39px')
  greet.position(0,50);
  
  inp = createInput(" ");
  inp.position(100,300);
  inp.size(200,25)
  
  button = createButton('submit');
  button.position(inp.x + inp.width/2 - button.width/2, inp.y + inp.height);
  button.mousePressed(start);
  
  //Control center
  //Background color
  bg = createSpan('Background color:');
  bg.position(width + 5, 0)
  //bg.hide();
  bgcolor = createColorPicker('#edebeb');
  bgcolor.position(width + 5, bg.height + 2);
  bgcolor.size(100,9);
  //bgcolor.hide();

  //Text
  tcolor = createSpan('Font color:');
  tcolor.position(width + 5, bgcolor.y + bgcolor.height + 5)
  fontcolor = createColorPicker('#000000');
  fontcolor.position(width + 5, tcolor.y + tcolor.height + 5);
  fontcolor.size(100,9);
  tsize = createSpan('Font size:');
  tsize.position(width + 5, fontcolor.y + fontcolor.height + 5);
  fontsize = createSlider(12,72,20,1);
  fontsize.position(width + 5, tsize.y + tsize.height + 5);
  fontsize.size(100);
  tfont = createSpan('Font:')
  tfont.position(width + 5, fontsize.y + fontsize.height + 5);
  selectedFont = createSlider(0,7,0,1);
  selectedFont.position(width + 5, tfont.y + tfont.height + 5 );
  selectedFont.size(100);
  
  
  
  
  //Adding
  add = createSpan('Add:');
  add.position(width +5, selectedFont.y + selectedFont.height + 8);
  adding = createSelect();
  adding.option('None');
  adding.option("Text");
  adding.option("Frame");
  adding.changed(addingChanged);
  adding.position(add.x+add.width +15, add.y)

  //Sub-text
  addText = createInput();
  addText.position(add.x, add.y + add.height +5)
  addText.size(100);
  addText.hide();
    //Coordination
  pos = createSpan('Coordination:');
  pos.position(width +5, addText.y + addText.height + 8);
  pos.hide();
  xpos = createSlider(0,width,100,1);
  xpos.position(width + 5,pos.y + pos.height + 5);
  xpos.size(100);
  xpos.hide();
  ypos = createSlider(0,height,100,1);
  ypos.position(width + 5,xpos.y + xpos.height + 5);
  ypos.size(100);
  ypos.hide();
  tAdd = createButton('Apply')
  tAdd.position(width + 70, ypos.y + ypos.height + 8)
  tAdd.mousePressed(textAdded)
  tAdd.hide();
  
  
  //Frame
  frame = createSpan('Frame mode:');
  frame.position(width +5, add.y + add.height + 5);
  frame.hide()
  fmode = createSlider(0,10,2,1);
  fmode.position(width +5, frame.y + frame.height + 5);
  fmode.size(100);
  fmode.hide();
  fcolor = createSpan('Frame color:');
  fcolor.position(width + 5, fmode.y + fmode.height + 5);
  fcolor.hide();
  framecolor = createColorPicker('#000000');
  framecolor.position(width + 5, fcolor.y + fcolor.height + 5); 
  framecolor.size(100,9);
  framecolor.hide();
  fAdd = createButton('Apply');
  fAdd.position(width + 70, framecolor.y + framecolor.height + 8)
  fAdd.mousePressed(frameAdded)
  fAdd.hide();
  
  //Save
  s = createButton('Save');
  s.position(width + 5, height - s.height)
  s.size(100)
  s.mouseClicked(saveLogo);
}

function start(){
  logo.push(brandName);
  greet.hide();
  inp.hide();
  button.hide();
  bg.show();
  bgcolor.show();
  nselected = false;
  
  
}

function TXT(content,x,y,size,color,font){
  this.x = x;
  this.y = y;
  this.content = content;
  this.color = color;
  this.size = size;
  this.font = font
  this.mouseOver = false;
  
  this.show = function(){
    fill(this.color);
    textSize(this.size);
    textFont(this.font);
    text(this.content, this.x, this.y);
  }
}

function Frame(numVertices,color){
  this.numVertices = numVertices;
  this.color = color

  this.show = function(){
    push();
    translate(width/2,height/2);
    noFill();
    strokeWeight(2);
    stroke(color);

    this.spacing = 360 / this.numVertices;
    beginShape();

    for(let i = 0; i < this.numVertices+1; i++) {

      this.angle = i * this.spacing;
      this.x = cos(radians(this.angle)) * 100;
      this.y = sin(radians(this.angle)) * 100;

      if(i == 0) {

        vertex(this.x, this.y);
      }
      else {

        this.cAngle = this.angle - this.spacing/2;
        this.cX = cos(radians(this.cAngle)) * 180;
        this.cY = sin(radians(this.cAngle)) * 180;
        quadraticVertex(this.cX, this.cY, this.x, this.y)
      }
    }
    endShape();
    pop();
  }
}
  
function draw(){
  
  background(bgcolor.color());
  
  //Looking at the preview before apply elements.
  if(nselected == true){
    brandName = new TXT(inp.value(),width/2,height/2, fontsize.value(),fontcolor.color(),font[selectedFont.value()], );
    brandName.show();
  }
  
  if(tselected == true){
    txtX = 100;
    txtY = 100;
    txt = new TXT(addText.value(),xpos.value(),ypos.value(),fontsize.value(),fontcolor.color(),font[selectedFont.value()]);
    txt.show();
  }
  
  if(fselected == true){
    f = new Frame(fmode.value(),framecolor.color());
    f.show();
  }
  
  for (var i = 0; i<logo.length; i++){
    logo[i].show();
  }
}

function addingChanged(){
  switch (adding.value()){
    case 'Text':
      addText.show();
      tAdd.show();
      pos.show();
      xpos.show();
      ypos.show();
      frame.hide()
      fmode.hide();
      fcolor.hide();
      framecolor.hide();
      fAdd.hide();
      tselected = true;
      break;
    case 'Frame':
      frame.show()
      fmode.show();
      fcolor.show();
      framecolor.show();
      fAdd.show();
      addText.hide();  
      tAdd.hide();
      pos.hide();
      xpos.hide();
      ypos.hide();
      fselected = true;
      break;
    case 'None':
      frame.hide()
      fmode.hide();
      fcolor.hide();
      framecolor.hide();
      fAdd.hide();
      addText.hide();  
      tAdd.hide();
      pos.hide();
      xpos.hide();
      ypos.hide();
      fselected = false;
      tselected = false;
  }
}

function frameAdded(){
  logo.push(f);
  fselected = false;
  frame.hide()
  fmode.hide();
  fcolor.hide();
  framecolor.hide();
  fAdd.hide();
}

function textAdded(){
  logo.push(txt);
  tselected = false;
  addText.hide();
  tAdd.hide();
  pos.hide();
  xpos.hide();
  ypos.hide();
  
}

function saveLogo(){
  save(cnv, 'myLogo.png')
}
